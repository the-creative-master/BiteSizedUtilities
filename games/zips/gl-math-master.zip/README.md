# ➕ Math Master

➕ Math Master — a modern, dependency-free HTML5 game built with Canvas and vanilla JavaScript.

🎮 **Play Online:** https://gamelabz.github.io/html5-game-math-master/

## 📸 Screenshot

![Math Master](assets/images/screenshot.png)

## 🎯 About

Solve arithmetic problems under time pressure and climb the difficulty as your streak grows.

## 🕹️ Controls

- Answer: Type / Click digits
- Submit: Enter
- Restart: R

## ✨ Features

- Mixed operations by level
- Timer and combo scoring
- Instant right/wrong feedback

## 🚀 Run Locally

No installation required. Open the game directly in a browser:

```bash
# Option A: just open the file
open index.html

# Option B: serve it with a tiny static server
npx serve .
```

Then visit the printed URL (default `http://localhost:3000`).

## 🛠️ Tech Stack

- HTML5 `<canvas>`
- CSS3 (custom properties, flexbox, glassmorphism)
- Vanilla JavaScript (ES2020, no frameworks)

## 🤝 Contributing

Contributions are welcome! To contribute:

1. Fork the repository.
2. Create a feature branch (`git checkout -b feature/my-idea`).
3. Commit your changes (`git commit -m "Add my idea"`).
4. Push to the branch (`git push origin feature/my-idea`).
5. Open a Pull Request.

Please keep the game dependency-free and test it in your browser before submitting.

## 📄 License

This project is licensed under the [MIT License](LICENSE) — a free and open-source license.

---

Let's Build Something Together 🚀
https://tally.so/r/q4q1L9
