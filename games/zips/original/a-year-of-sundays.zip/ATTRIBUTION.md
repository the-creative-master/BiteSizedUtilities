# Attribution

A Year of Sundays is original first-party work.
