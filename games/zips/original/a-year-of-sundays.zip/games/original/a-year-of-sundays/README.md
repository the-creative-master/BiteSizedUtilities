# A Year of Sundays

Steer a year of small life choices; balance energy, joy, craft, and connection. Make gentle choices through twelve seasons.

Controls: Pick one of three choices each season.

Original first-party work, MIT licensed.
