# Attribution

Afterglow Numbers is original first-party work.
