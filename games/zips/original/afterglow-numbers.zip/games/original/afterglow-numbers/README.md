# Afterglow Numbers

Slide matching numbered shells together to reach the target score. Score big before the board fills.

Controls: Arrow keys / WASD or swipe to slide.

Original first-party work, MIT licensed.
