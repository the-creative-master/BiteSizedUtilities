# Attribution

Aurora Traverse is original first-party work.
