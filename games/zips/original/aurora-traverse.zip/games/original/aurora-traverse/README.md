# Aurora Traverse

Pilot a tiny rover over bumpy terrain; manage speed, fuel, and landing angle. Cross a longer, steeper alien valley.

Controls: Up/W accelerate; Down/S brake; left/right balance.

Original first-party work, MIT licensed.
