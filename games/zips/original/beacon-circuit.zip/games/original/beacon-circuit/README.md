# Beacon Circuit

Trace numbered beacons in order while avoiding the storm tiles. Follow the numbered route across safe ground.

Controls: Click the next number in order; restart any time.

Original first-party work, MIT licensed.
