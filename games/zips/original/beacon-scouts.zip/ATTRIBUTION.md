# Attribution

Beacon Scouts is original first-party work.
