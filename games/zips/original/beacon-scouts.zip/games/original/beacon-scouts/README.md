# Beacon Scouts

Move your explorer across a compact tactical board to secure the beacon. Step through a compact hazard board.

Controls: Click a highlighted neighboring tile; avoid hazards.

Original first-party work, MIT licensed.
