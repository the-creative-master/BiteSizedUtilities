# Bicycle Crossing

Guide a small stream of cyclists and carts safely through a busy crossing. Send every cyclist through a safe opening.

Controls: Click a vehicle to send it across when the lane is clear.

Original first-party work, MIT licensed.
