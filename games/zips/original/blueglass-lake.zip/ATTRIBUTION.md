# Attribution

Blueglass Lake is original first-party work.
