# Blueglass Lake

Cast near a ripple, then reel only when a fish tugs the line. Read several ripples to land a bigger catch.

Controls: Cast; watch the float; press Reel at the tug.

Original first-party work, MIT licensed.
