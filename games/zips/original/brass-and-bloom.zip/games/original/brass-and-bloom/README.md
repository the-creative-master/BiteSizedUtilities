# Brass & Bloom

Build a clever hand from three actions each turn to outlast the rival automaton. Spend energy carefully across a longer duel.

Controls: Choose a card each turn; defend, strike, or recharge.

Original first-party work, MIT licensed.
