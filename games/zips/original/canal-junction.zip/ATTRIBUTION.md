# Attribution

Canal Junction is original first-party work.
