# Canal Junction

Guide a small stream of cyclists and carts safely through a busy crossing. Coordinate boats and carts without a collision.

Controls: Click a vehicle to send it across when the lane is clear.

Original first-party work, MIT licensed.
