# Canyon Courier

Pilot a tiny rover over bumpy terrain; manage speed, fuel, and landing angle. Carry a fragile parcel over two ridges.

Controls: Up/W accelerate; Down/S brake; left/right balance.

Original first-party work, MIT licensed.
