# Cinnamon Cart

Run a tiny stall: buy ingredients, set a fair price, then serve the changing crowd. Stock a tiny cart for an evening crowd.

Controls: Choose stock, price, and Serve; adapt to demand.

Original first-party work, MIT licensed.
