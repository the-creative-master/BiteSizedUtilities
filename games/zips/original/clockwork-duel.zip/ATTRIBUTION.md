# Attribution

Clockwork Duel is original first-party work.
