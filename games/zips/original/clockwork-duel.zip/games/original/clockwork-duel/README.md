# Clockwork Duel

Build a clever hand from three actions each turn to outlast the rival automaton. Outsmart a small rival with a three-card hand.

Controls: Choose a card each turn; defend, strike, or recharge.

Original first-party work, MIT licensed.
