# Clockwork Waltz

Tap the beat as glowing rings meet the center; stay on tempo for a combo. Tap a steady sequence of bright beats.

Controls: Space, Enter, or tap when the ring reaches center.

Original first-party work, MIT licensed.
