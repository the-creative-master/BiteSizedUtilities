# Cloudstone Stack

Slide matching numbered shells together to reach the target score. Use careful slides to grow a taller chain.

Controls: Arrow keys / WASD or swipe to slide.

Original first-party work, MIT licensed.
