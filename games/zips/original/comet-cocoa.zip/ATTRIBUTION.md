# Attribution

Comet Cocoa is original first-party work.
