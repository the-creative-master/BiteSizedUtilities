# Comet Cocoa

Run a tiny stall: buy ingredients, set a fair price, then serve the changing crowd. Serve a changing crowd before closing time.

Controls: Choose stock, price, and Serve; adapt to demand.

Original first-party work, MIT licensed.
