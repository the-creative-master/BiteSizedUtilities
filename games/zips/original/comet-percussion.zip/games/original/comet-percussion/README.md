# Comet Percussion

Tap the beat as glowing rings meet the center; stay on tempo for a combo. Keep combo through a brisk pattern.

Controls: Space, Enter, or tap when the ring reaches center.

Original first-party work, MIT licensed.
