# Attribution

Copper Kettle is original first-party work.
