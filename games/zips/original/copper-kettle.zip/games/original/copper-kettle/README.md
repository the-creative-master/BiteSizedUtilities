# Copper Kettle

Untangle a fresh word from its scattered letters before the lantern fades. Untangle trickier words with one spare hint.

Controls: Tap letters to build the word, then Submit.

Original first-party work, MIT licensed.
