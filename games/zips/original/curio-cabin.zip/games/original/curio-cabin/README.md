# Curio Cabin

Answer original bite-sized nature, science, and everyday logic questions. Keep a streak through mixed brain teasers.

Controls: Choose an answer; streaks earn bonus points.

Original first-party work, MIT licensed.
