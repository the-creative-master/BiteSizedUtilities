# Dusk Estuary

Cast near a ripple, then reel only when a fish tugs the line. Fish through a longer sequence of changing tugs.

Controls: Cast; watch the float; press Reel at the tug.

Original first-party work, MIT licensed.
