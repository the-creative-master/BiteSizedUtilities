# Dusty Switchbacks

Pilot a tiny rover over bumpy terrain; manage speed, fuel, and landing angle. Brake carefully and conserve charge.

Controls: Up/W accelerate; Down/S brake; left/right balance.

Original first-party work, MIT licensed.
