# Everyday Wonders

Answer original bite-sized nature, science, and everyday logic questions. A broader quiz with a short time limit.

Controls: Choose an answer; streaks earn bonus points.

Original first-party work, MIT licensed.
