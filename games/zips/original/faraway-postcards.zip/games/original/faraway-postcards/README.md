# Faraway Postcards

Steer a year of small life choices; balance energy, joy, craft, and connection. Balance curiosity, rest, and belonging on a journey.

Controls: Pick one of three choices each season.

Original first-party work, MIT licensed.
