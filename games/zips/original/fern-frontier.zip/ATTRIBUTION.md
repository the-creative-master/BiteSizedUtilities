# Attribution

Fern Frontier is original first-party work.
