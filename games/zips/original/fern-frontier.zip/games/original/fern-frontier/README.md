# Fern Frontier

Place friendly sentry sprouts along a winding trail and stop the beetle rush. Defend the whole winding trail through three waves.

Controls: Select a sprout, click a plot to place it, then launch a wave.

Original first-party work, MIT licensed.
