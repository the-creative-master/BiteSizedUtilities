# Festival Crossing

Guide a small stream of cyclists and carts safely through a busy crossing. Keep a larger crowd moving safely.

Controls: Click a vehicle to send it across when the lane is clear.

Original first-party work, MIT licensed.
