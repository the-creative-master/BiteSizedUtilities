# Frostline Patrol

Move your explorer across a compact tactical board to secure the beacon. Navigate a broader tactical field under pressure.

Controls: Click a highlighted neighboring tile; avoid hazards.

Original first-party work, MIT licensed.
