# Garden Green

Sink a short putt through bumpers with a measured angle and power. Navigate a bend and a banked obstacle.

Controls: Set angle with left/right; power with up/down; Shoot.

Original first-party work, MIT licensed.
