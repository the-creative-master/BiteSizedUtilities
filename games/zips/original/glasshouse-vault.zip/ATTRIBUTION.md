# Attribution

Glasshouse Vault is original first-party work.
