# Glasshouse Vault

Crack a four-symbol code with color feedback and a limited number of probes. A tighter code offers fewer guesses.

Controls: Tap a dial to cycle symbols; Submit each guess.

Original first-party work, MIT licensed.
