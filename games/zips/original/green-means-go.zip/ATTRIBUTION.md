# Attribution

Green Means Go is original first-party work.
