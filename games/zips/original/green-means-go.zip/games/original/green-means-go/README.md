# Green Means Go

Wait through a changing signal, then react only when the green flare appears. Wait for the safe signal and resist false starts.

Controls: Click/tap or Space only on green; false starts cost a life.

Original first-party work, MIT licensed.
