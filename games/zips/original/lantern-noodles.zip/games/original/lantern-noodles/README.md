# Lantern Noodles

Run a tiny stall: buy ingredients, set a fair price, then serve the changing crowd. Balance price and supplies through a busy shift.

Controls: Choose stock, price, and Serve; adapt to demand.

Original first-party work, MIT licensed.
