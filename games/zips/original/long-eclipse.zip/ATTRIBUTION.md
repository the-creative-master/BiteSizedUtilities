# Attribution

Long Eclipse is original first-party work.
