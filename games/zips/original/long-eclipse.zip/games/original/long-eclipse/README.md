# Long Eclipse

Protect a tiny moon by intercepting incoming debris before impact. Survive a dense, accelerating debris field.

Controls: Click/tap a debris marker to intercept.

Original first-party work, MIT licensed.
