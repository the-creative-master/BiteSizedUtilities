# Attribution

Meadow Patch is original first-party work.
