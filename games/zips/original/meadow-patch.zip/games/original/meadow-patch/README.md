# Meadow Patch

Keep a tiny habitat thriving by balancing water, shade, and pollinators. Balance shade and pollinators in a broad meadow.

Controls: Choose a restoration action each turn.

Original first-party work, MIT licensed.
