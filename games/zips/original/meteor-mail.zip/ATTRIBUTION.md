# Attribution

Meteor Mail is original first-party work.
