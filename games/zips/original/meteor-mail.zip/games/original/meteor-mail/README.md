# Meteor Mail

Dodge traffic and collect charge on a three-lane delivery sprint. Swerve through a fast comet-tail route.

Controls: Left/right arrows or tap a lane.

Original first-party work, MIT licensed.
