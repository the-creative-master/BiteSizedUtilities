# Moonlit Letters

Untangle a fresh word from its scattered letters before the lantern fades. Solve a rotating set of longer word tangles.

Controls: Tap letters to build the word, then Submit.

Original first-party work, MIT licensed.
