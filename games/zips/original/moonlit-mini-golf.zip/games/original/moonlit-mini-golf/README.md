# Moonlit Mini-Golf

Sink a short putt through bumpers with a measured angle and power. Sink the glowing orb through a curved lane.

Controls: Set angle with left/right; power with up/down; Shoot.

Original first-party work, MIT licensed.
