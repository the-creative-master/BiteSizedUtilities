# Moonseed Climb

Leap between floating ledges, collect sparks, and reach the beacon. Collect the scattered seeds on a tall ascent.

Controls: Arrows / A-D move; Space / Up jump.

Original first-party work, MIT licensed.
