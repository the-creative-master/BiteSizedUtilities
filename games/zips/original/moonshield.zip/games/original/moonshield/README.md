# Moonshield

Protect a tiny moon by intercepting incoming debris before impact. Deflect a brief shower of space pebbles.

Controls: Click/tap a debris marker to intercept.

Original first-party work, MIT licensed.
