# Moonwell Maze

Find the exit through a newly woven maze before your energy runs out. Find the distant exit in a broad labyrinth.

Controls: Arrow keys / WASD or touch the direction buttons.

Original first-party work, MIT licensed.
