# Mossy Melodies

Repeat a growing sequence of glowing notes; each round adds a new beat. Repeat a four-pad garden melody.

Controls: Tap the pads in the shown order.

Original first-party work, MIT licensed.
