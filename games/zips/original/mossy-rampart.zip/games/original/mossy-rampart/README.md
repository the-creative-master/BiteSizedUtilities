# Mossy Rampart

Place friendly sentry sprouts along a winding trail and stop the beetle rush. Combine slow and rapid sprouts across two waves.

Controls: Select a sprout, click a plot to place it, then launch a wave.

Original first-party work, MIT licensed.
