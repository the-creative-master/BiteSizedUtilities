# Night Crossing

Wait through a changing signal, then react only when the green flare appears. Keep your nerve through a series of signals.

Controls: Click/tap or Space only on green; false starts cost a life.

Original first-party work, MIT licensed.
