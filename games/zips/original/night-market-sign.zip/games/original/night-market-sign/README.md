# Night Market Sign

Reveal the hidden pixel picture using row and column clue counts. Reveal a larger pixel sign from clues.

Controls: Click/tap cells to cycle blank, filled, or marked; use row/column totals, then Check.

Original first-party work, MIT licensed.
