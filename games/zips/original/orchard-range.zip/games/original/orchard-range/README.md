# Orchard Range

Read the shifting breeze and time a clean shot at the moving target. Adjust to crosswind across five shots.

Controls: Adjust aim with left/right, then Space or Shoot.

Original first-party work, MIT licensed.
