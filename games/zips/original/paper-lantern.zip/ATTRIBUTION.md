# Attribution

Paper Lantern is original first-party work.
