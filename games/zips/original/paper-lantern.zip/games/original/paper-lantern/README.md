# Paper Lantern

Reveal the hidden pixel picture using row and column clue counts. Decode the small lantern mosaic.

Controls: Click/tap cells to cycle blank, filled, or marked; use row/column totals, then Check.

Original first-party work, MIT licensed.
