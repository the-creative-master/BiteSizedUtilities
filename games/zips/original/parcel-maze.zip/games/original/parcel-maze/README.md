# Parcel Maze

Find the exit through a newly woven maze before your energy runs out. Deliver a parcel to the blue door.

Controls: Arrow keys / WASD or touch the direction buttons.

Original first-party work, MIT licensed.
