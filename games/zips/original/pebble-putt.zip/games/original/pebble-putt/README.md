# Pebble Putt

Sink a short putt through bumpers with a measured angle and power. Put the ball around two soft bumpers.

Controls: Set angle with left/right; power with up/down; Shoot.

Original first-party work, MIT licensed.
