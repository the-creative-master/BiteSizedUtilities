# Attribution

Pocket Naturalist is original first-party work.
