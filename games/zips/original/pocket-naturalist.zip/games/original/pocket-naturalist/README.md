# Pocket Naturalist

Answer original bite-sized nature, science, and everyday logic questions. A quick set of original curiosity questions.

Controls: Choose an answer; streaks earn bonus points.

Original first-party work, MIT licensed.
