# Pollen Pilot

Leap between floating ledges, collect sparks, and reach the beacon. Hop over gaps and gather three sparks.

Controls: Arrows / A-D move; Space / Up jump.

Original first-party work, MIT licensed.
