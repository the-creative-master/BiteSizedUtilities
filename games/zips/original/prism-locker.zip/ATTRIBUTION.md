# Attribution

Prism Locker is original first-party work.
