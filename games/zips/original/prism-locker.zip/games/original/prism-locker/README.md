# Prism Locker

Crack a four-symbol code with color feedback and a limited number of probes. Open the four-dial color lock in six tries.

Controls: Tap a dial to cycle symbols; Submit each guess.

Original first-party work, MIT licensed.
