# Attribution

Quiet Orbit is original first-party work.
