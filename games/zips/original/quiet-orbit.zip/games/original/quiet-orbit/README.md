# Quiet Orbit

Protect a tiny moon by intercepting incoming debris before impact. Protect two satellites from incoming shards.

Controls: Click/tap a debris marker to intercept.

Original first-party work, MIT licensed.
