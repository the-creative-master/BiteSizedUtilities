# Rain Garden

Keep a tiny habitat thriving by balancing water, shade, and pollinators. Restore a small habitat before the dry season.

Controls: Choose a restoration action each turn.

Original first-party work, MIT licensed.
