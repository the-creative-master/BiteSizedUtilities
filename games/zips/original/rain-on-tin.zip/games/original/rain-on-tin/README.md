# Rain on Tin

Tap the beat as glowing rings meet the center; stay on tempo for a combo. Follow a shifting syncopated rhythm.

Controls: Space, Enter, or tap when the ring reaches center.

Original first-party work, MIT licensed.
