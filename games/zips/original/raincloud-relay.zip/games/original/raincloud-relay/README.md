# Raincloud Relay

Leap between floating ledges, collect sparks, and reach the beacon. Reach the high beacon above the stream.

Controls: Arrows / A-D move; Space / Up jump.

Original first-party work, MIT licensed.
