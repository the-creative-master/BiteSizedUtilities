# Rainroom Refrain

Repeat a growing sequence of glowing notes; each round adds a new beat. Keep up as the sequence grows faster.

Controls: Tap the pads in the shown order.

Original first-party work, MIT licensed.
