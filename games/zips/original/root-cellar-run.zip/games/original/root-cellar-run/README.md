# Root Cellar Run

Find the exit through a newly woven maze before your energy runs out. Take a winding route with limited steps.

Controls: Arrow keys / WASD or touch the direction buttons.

Original first-party work, MIT licensed.
