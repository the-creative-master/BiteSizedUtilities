# Ruin Runners

Move your explorer across a compact tactical board to secure the beacon. Reach the beacon before the board shifts.

Controls: Click a highlighted neighboring tile; avoid hazards.

Original first-party work, MIT licensed.
