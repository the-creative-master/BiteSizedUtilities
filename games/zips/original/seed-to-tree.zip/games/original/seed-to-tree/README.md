# Seed to Tree

Transform one word into another by changing a single letter per rung. Complete a longer chain of changing words.

Controls: Choose a letter, then Submit; every rung must be a word.

Original first-party work, MIT licensed.
