# Signal Lantern

Wait through a changing signal, then react only when the green flare appears. React to a less predictable pause.

Controls: Click/tap or Space only on green; false starts cost a life.

Original first-party work, MIT licensed.
