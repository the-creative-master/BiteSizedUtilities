# Sprout Sentinels

Place friendly sentry sprouts along a winding trail and stop the beetle rush. Set a few seed turrets along the path.

Controls: Select a sprout, click a plot to place it, then launch a wave.

Original first-party work, MIT licensed.
