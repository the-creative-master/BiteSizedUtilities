# Starling Song

Repeat a growing sequence of glowing notes; each round adds a new beat. Build a longer note chain without a miss.

Controls: Tap the pads in the shown order.

Original first-party work, MIT licensed.
