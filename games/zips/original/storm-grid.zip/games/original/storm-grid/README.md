# Storm Grid

Trace numbered beacons in order while avoiding the storm tiles. Trace a longer route around the flashing danger cells.

Controls: Click the next number in order; restart any time.

Original first-party work, MIT licensed.
