# Sunset Switchback

Trace numbered beacons in order while avoiding the storm tiles. Complete the winding beacon trail before dusk.

Controls: Click the next number in order; restart any time.

Original first-party work, MIT licensed.
