# Tea & Thistle

Untangle a fresh word from its scattered letters before the lantern fades. Make a cozy word from a hand of letters.

Controls: Tap letters to build the word, then Submit.

Original first-party work, MIT licensed.
