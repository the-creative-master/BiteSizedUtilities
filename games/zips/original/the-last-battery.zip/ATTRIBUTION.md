# Attribution

The Last Battery is original first-party work.
