# The Last Battery

Build a clever hand from three actions each turn to outlast the rival automaton. Win an endurance bout with limited healing.

Controls: Choose a card each turn; defend, strike, or recharge.

Original first-party work, MIT licensed.
