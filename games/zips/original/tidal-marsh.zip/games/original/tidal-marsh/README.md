# Tidal Marsh

Keep a tiny habitat thriving by balancing water, shade, and pollinators. Keep a delicate wetland resilient through shifts.

Controls: Choose a restoration action each turn.

Original first-party work, MIT licensed.
