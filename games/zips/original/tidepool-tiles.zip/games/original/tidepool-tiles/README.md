# Tidepool Tiles

Slide matching numbered shells together to reach the target score. Merge shells and reach the tide marker.

Controls: Arrow keys / WASD or swipe to slide.

Original first-party work, MIT licensed.
