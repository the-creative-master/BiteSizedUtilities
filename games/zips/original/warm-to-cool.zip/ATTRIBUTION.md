# Attribution

Warm to Cool is original first-party work.
