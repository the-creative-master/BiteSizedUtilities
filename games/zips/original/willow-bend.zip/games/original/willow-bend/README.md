# Willow Bend

Cast near a ripple, then reel only when a fish tugs the line. Find a bite in the reeds and reel at the right moment.

Controls: Cast; watch the float; press Reel at the tug.

Original first-party work, MIT licensed.
