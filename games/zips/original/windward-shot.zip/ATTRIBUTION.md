# Attribution

Windward Shot is original first-party work.
