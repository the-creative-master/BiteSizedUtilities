# Windward Shot

Read the shifting breeze and time a clean shot at the moving target. Land three arrows on the drifting target.

Controls: Adjust aim with left/right, then Space or Shoot.

Original first-party work, MIT licensed.
