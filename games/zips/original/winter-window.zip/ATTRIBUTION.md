# Attribution

Winter Window is original first-party work.
