# Winter Window

Reveal the hidden pixel picture using row and column clue counts. Solve a denser seasonal picture grid.

Controls: Click/tap cells to cycle blank, filled, or marked; use row/column totals, then Check.

Original first-party work, MIT licensed.
