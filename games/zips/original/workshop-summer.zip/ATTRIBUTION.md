# Attribution

Workshop Summer is original first-party work.
