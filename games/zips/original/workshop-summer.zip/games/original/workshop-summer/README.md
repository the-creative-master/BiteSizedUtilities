# Workshop Summer

Steer a year of small life choices; balance energy, joy, craft, and connection. Grow a craft and friendships without burning out.

Controls: Pick one of three choices each season.

Original first-party work, MIT licensed.
